onmessage = function(e) {
	console.log("importScripts('nim_test05.js')");

	importScripts('nim_test05.js');
};